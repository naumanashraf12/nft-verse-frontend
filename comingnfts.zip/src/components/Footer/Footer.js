import React from "react";

const Footer = () => {
  return (
    <div>
      <div
        className="d-flex justify-content-center align-contnet-center"
        style={{
          borderTop: "2px solid black",
        }}
      >
        <div>
          <h3
            style={{
              color: "black",
              fontWeight: "bold",
            }}
          >
            NFT.VERSE.ART
          </h3>
        </div>
      </div>
    </div>
  );
};

export default Footer;
